// Cloudflare Worker for LONG AI PLANT DOCTOR V2
// Configure Secrets: OPENAI_API_KEY and APP_ACCESS_CODE.
// Optional variable: OPENAI_MODEL. Never put API keys in frontend or GitHub.
const corsHeaders = {
  "Access-Control-Allow-Origin": "*", // Replace * with exact GitHub Pages origin before production.
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};
export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, {headers:corsHeaders});
    if (request.method !== "POST") return json({error:"Chỉ hỗ trợ POST."},405);
    if (!env.OPENAI_API_KEY || !env.APP_ACCESS_CODE) return json({error:"Máy chủ chưa cấu hình Secrets."},500);
    let body; try { body=await request.json(); } catch { return json({error:"JSON không hợp lệ."},400); }
    if (!body || body.accessCode !== env.APP_ACCESS_CODE) return json({error:"Mã truy cập không đúng."},401);
    if (!Array.isArray(body.images) || body.images.length<1 || body.images.length>4) return json({error:"Cần từ 1 đến 4 ảnh."},400);
    const imgs=body.images.filter(x=>typeof x==="string" && /^data:image\/(jpeg|png|webp);base64,/.test(x));
    if (!imgs.length) return json({error:"Không có ảnh hợp lệ."},400);
    const s=v=>String(v||"Chưa cung cấp").slice(0,1800);
    const prompt=`Bạn là trợ lý hỗ trợ chẩn đoán thực vật cho kỹ sư nông nghiệp ở Việt Nam. Phân tích ảnh thực tế và thông tin:
Cây người dùng khai báo: ${s(body.crop)}
Giai đoạn: ${s(body.stage)}
Vùng: ${s(body.area)}
Giống/tuổi: ${s(body.cultivar)}
Triệu chứng: ${s(body.symptoms)}
Điều kiện: ${s(body.conditions)}

YÊU CẦU:
1. Nhận diện cây nếu hình ảnh đủ dấu hiệu; nếu không, nêu các khả năng và yêu cầu ảnh đặc trưng. Không tự nhận diện chắc chắn chỉ từ lá khi nhiều loài giống nhau.
2. Mô tả dấu hiệu thực sự thấy trong ảnh, tách khỏi suy luận.
3. Đưa tối đa 3 chẩn đoán phân biệt cho nấm/bệnh, sâu, rầy, nhện, côn trùng hoặc nguyên nhân phi sinh học. Nêu dấu hiệu ủng hộ, dấu hiệu thiếu, mức tin cậy thấp/vừa/cao bằng chữ (không phải xác suất đã hiệu chuẩn).
4. Đề xuất kiểm tra thực địa ít rủi ro, ảnh cần chụp thêm và thông tin cần hỏi.
5. Không kê công thức phối trộn thuốc, không tự bịa tên thương phẩm, đăng ký, liều lượng hay thời gian cách ly. Chỉ hướng dẫn người dùng xác minh nhãn và danh mục hiện hành tại Việt Nam, đúng cây và đúng đối tượng gây hại.
6. Ưu tiên IPM, vệ sinh đồng ruộng, quản lý nước/dinh dưỡng phù hợp; không khuyến cáo phun khi chưa xác định đối tượng. Lưu ý ong thụ phấn, thiên địch, PPE và PHI.
7. Không tuyên bố bệnh đã xác nhận khi cần xét nghiệm hoặc kiểm tra chuyên gia.
Trả lời tiếng Việt với mục: A. Cây nhận diện và mức tin cậy; B. Quan sát ảnh; C. Chẩn đoán phân biệt; D. Kiểm tra tiếp; E. Quản lý tạm thời; F. Thuốc BVTV—điều gì chưa được xác minh.`;
    try {
      const content=[{type:"input_text",text:prompt}];
      for(const image_url of imgs) content.push({type:"input_image",image_url,detail:"high"});
      const upstream=await fetch("https://api.openai.com/v1/responses",{
        method:"POST",headers:{"Authorization":`Bearer ${env.OPENAI_API_KEY}`,"Content-Type":"application/json"},
        body:JSON.stringify({model:env.OPENAI_MODEL||"gpt-4.1-mini",input:[{role:"user",content}],max_output_tokens:1600})
      });
      const r=await upstream.json();
      if(!upstream.ok)return json({error:`AI API HTTP ${upstream.status}: ${r.error?.message||"Không có chi tiết"}`},502);
      const analysis=extract(r);
      if(!analysis)return json({error:"Phản hồi AI không có nội dung văn bản."},502);
      return json({analysis,model:env.OPENAI_MODEL||"gpt-4.1-mini"},200);
    }catch(e){return json({error:"Không gọi được AI: "+String(e.message||e)},502)}
  }
};
function extract(r){if(typeof r.output_text==="string")return r.output_text;const a=[];for(const o of r.output||[])for(const c of o.content||[])if(c.type==="output_text"&&c.text)a.push(c.text);return a.join("\n")}
function json(o,status=200){return new Response(JSON.stringify(o),{status,headers:{...corsHeaders,"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}})}