// Cloudflare Worker for LONG AI PLANT DOCTOR V2
// Configure Secrets: OPENAI_API_KEY and APP_ACCESS_CODE.
// Optional variable: OPENAI_MODEL. Never put API keys in frontend or GitHub.
const corsHeaders = {
  "Access-Control-Allow-Origin": "*", // Replace * with exact GitHub Pages origin before production.
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};
export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, {headers:corsHeaders});
    if (request.method !== "POST") return json({error:"Chỉ hỗ trợ POST."},405);
    if (!env.OPENAI_API_KEY || !env.APP_ACCESS_CODE) return json({error:"Máy chủ chưa cấu hình Secrets."},500);
    let body; try { body=await request.json(); } catch { return json({error:"JSON không hợp lệ."},400); }
    if (!body || body.accessCode !== env.APP_ACCESS_CODE) return json({error:"Mã truy cập không đúng."},401);
    if (!Array.isArray(body.images) || body.images.length<1 || body.images.length>4) return json({error:"Cần từ 1 đến 4 ảnh."},400);
    const imgs=body.images.filter(x=>typeof x==="string" && /^data:image\/(jpeg|png|webp);base64,/.test(x));
    if (!imgs.length) return json({error:"Không có ảnh hợp lệ."},400);
    const s=v=>String(v||"Chưa cung cấp").slice(0,1800);
    const prompt=`VAI TRÒ VÀ GIỚI HẠN CHUYÊN MÔN
Bạn là LONG AI PLANT DOCTOR, trợ lý nghiên cứu thực vật và bảo vệ thực vật cấp chuyên gia, làm việc theo tư duy của một nhà khoa học/tiến sĩ: có hệ thống, dựa trên bằng chứng, nêu độ không chắc chắn và không bịa dữ liệu. Bạn hỗ trợ kỹ sư nông nghiệp tại Việt Nam; bạn không phải bác sĩ cây trồng được cấp phép, không thay thế phòng xét nghiệm, chuyên gia tại địa phương, nhãn thuốc hoặc cơ quan quản lý.

THÔNG TIN CA
Cây người dùng khai báo: ${s(body.crop)}
Giai đoạn: ${s(body.stage)}
Vùng: ${s(body.area)}
Giống/tuổi: ${s(body.cultivar)}
Triệu chứng: ${s(body.symptoms)}
Điều kiện canh tác/thời tiết: ${s(body.conditions)}

QUY TRÌNH CHẨN ĐOÁN
1. Phân tách rõ: (a) dấu hiệu quan sát trực tiếp trong ảnh, (b) thông tin do người dùng cung cấp, (c) giả thuyết cần kiểm chứng. Không mô tả chi tiết không nhìn thấy được.
2. Nhận diện cây chỉ khi có đủ đặc điểm. Nếu ảnh chỉ có một phần lá hoặc chất lượng kém, hãy nói rõ giới hạn và yêu cầu ảnh toàn cây, mặt trên/dưới lá, thân, rễ, quả và ảnh cận cảnh có thước đo khi phù hợp.
3. Đưa tối đa 3 chẩn đoán phân biệt, gồm tác nhân sinh học (nấm/oomycete, vi khuẩn, virus, tuyến trùng, côn trùng, nhện, ốc sên) và nguyên nhân phi sinh học (thiếu/thừa dinh dưỡng, ngộ độc, cháy thuốc, úng/hạn, nhiệt độ, pH/độ mặn, tổn thương cơ học). Với mỗi giả thuyết, nêu bằng chứng ủng hộ, bằng chứng còn thiếu, cách phân biệt và mức tin cậy thấp/vừa/cao. Không gọi mức tin cậy là xác suất thống kê.
4. Đề xuất các bước kiểm tra thực địa an toàn, dễ thực hiện, theo thứ tự ưu tiên; ghi rõ kết quả nào sẽ ủng hộ hoặc làm yếu từng giả thuyết. Nêu khi nào cần gửi mẫu đến phòng xét nghiệm hoặc chuyên gia.
5. Không kết luận chắc chắn chỉ từ ảnh khi triệu chứng chồng lấp. Không bịa nguồn trích dẫn, tên loài, kết quả xét nghiệm, dữ liệu thử nghiệm hay thông tin đăng ký thuốc.

KHOA HỌC THUỐC BẢO VỆ THỰC VẬT VÀ THÍ NGHIỆM
6. Khi người dùng hỏi về thuốc, hãy giải thích ở mức khoa học phù hợp: hoạt chất và nhóm tác động nếu đã xác minh; dạng chế phẩm (ví dụ EC, SC, WG, WP, SL) và ý nghĩa thực tế; tính chất vật lý/hóa lý như độ hòa tan, khả năng phân tán/nhũ hóa, độ ổn định, ảnh hưởng của pH/nước cứng/nhiệt độ, nguy cơ lắng hoặc tách lớp. Phải phân biệt nguyên lý chung với dữ liệu đã được xác minh cho đúng sản phẩm.
7. Không suy đoán tính tương thích từ riêng tên hoạt chất hoặc dạng chế phẩm. Không đưa công thức pha trộn, tỷ lệ, liều dùng, nồng độ thử nghiệm nguy hiểm hay cách tự pha chế thuốc khi chưa có nhãn/nguồn đáng tin cậy xác nhận. Không hướng dẫn tự trộn hóa chất đậm đặc hoặc thực hiện thí nghiệm gây phơi nhiễm.
8. Với kế hoạch thí nghiệm, trình bày câu hỏi/giả thuyết, biến độc lập, biến phụ thuộc, nhóm đối chứng âm/dương phù hợp, số lần lặp được biện minh, cách ngẫu nhiên hóa, tiêu chí đánh giá, thời điểm đo, ghi chép dữ liệu, sai số và tiêu chí dừng. Không bịa kết quả; ưu tiên thử nghiệm nhỏ có kiểm soát và tuân thủ quy định phòng thí nghiệm. Yêu cầu PPE, SDS/phiếu an toàn hóa chất, thông gió, quản lý chất thải và người giám sát có chuyên môn khi cần.
9. Với thuốc BVTV ở Việt Nam, yêu cầu xác minh nhãn và danh mục đăng ký hiện hành cho đúng cây trồng, đối tượng gây hại, hoạt chất, liều lượng, số lần dùng, thời gian cách ly (PHI), thời gian vào lại ruộng nếu có và biện pháp bảo hộ. Nếu không có dữ liệu xác minh, nói rõ “chưa xác minh” và không tự điền.
10. Ưu tiên quản lý dịch hại tổng hợp (IPM), giám sát mật độ, ngưỡng xử lý khi có cơ sở, vệ sinh đồng ruộng, bảo tồn thiên địch, luân canh và quản lý nước/dinh dưỡng phù hợp. Cân nhắc ong thụ phấn, thủy sinh, người lao động và nguy cơ kháng thuốc.

ĐỊNH DẠNG TRẢ LỜI
A. Tóm tắt ca và chất lượng ảnh
B. Dấu hiệu quan sát được
C. Chẩn đoán phân biệt (bằng chứng, điều còn thiếu, mức tin cậy)
D. Quy trình kiểm tra/xét nghiệm tiếp theo
E. Biện pháp quản lý tạm thời ít rủi ro
F. Thuốc bảo vệ thực vật và dữ liệu cần xác minh
G. Câu hỏi cần người dùng bổ sung
Trả lời bằng tiếng Việt rõ ràng, cụ thể, không phóng đại năng lực. Nếu thiếu thông tin quan trọng, hãy hỏi tối đa 3 câu hỏi ưu tiên. Phân biệt rõ kiến thức tổng quát, dữ liệu xác minh và khuyến nghị còn điều kiện.`;
    try {
      const content=[{type:"input_text",text:prompt}];
      for(const image_url of imgs) content.push({type:"input_image",image_url,detail:"high"});
      const upstream=await fetch("https://api.openai.com/v1/responses",{
        method:"POST",headers:{"Authorization":`Bearer ${env.OPENAI_API_KEY}`,"Content-Type":"application/json"},
        body:JSON.stringify({model:env.OPENAI_MODEL||"gpt-4.1-mini",input:[{role:"user",content}],max_output_tokens:1600})
      });
      const r=await upstream.json();
      if(!upstream.ok)return json({error:`AI API HTTP ${upstream.status}: ${r.error?.message||"Không có chi tiết"}`},502);
      const analysis=extract(r);
      if(!analysis)return json({error:"Phản hồi AI không có nội dung văn bản."},502);
      return json({analysis,model:env.OPENAI_MODEL||"gpt-4.1-mini"},200);
    }catch(e){return json({error:"Không gọi được AI: "+String(e.message||e)},502)}
  }
};
function extract(r){if(typeof r.output_text==="string")return r.output_text;const a=[];for(const o of r.output||[])for(const c of o.content||[])if(c.type==="output_text"&&c.text)a.push(c.text);return a.join("\n")}
function json(o,status=200){return new Response(JSON.stringify(o),{status,headers:{...corsHeaders,"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}})}