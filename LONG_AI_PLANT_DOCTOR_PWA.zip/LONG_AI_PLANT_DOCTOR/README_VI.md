# LONG AI PLANT DOCTOR — hướng dẫn triển khai trên Android

## Bản này làm được gì?
- PWA giao diện tiếng Việt, có thể thêm vào màn hình chính Android.
- Chụp ảnh bằng camera hoặc chọn tối đa 4 ảnh trong thư viện.
- Nén ảnh trên trình duyệt và gửi đến Cloudflare Worker.
- Worker gọi OpenAI Responses API để phân tích ảnh thật. Nếu chưa cấu hình API, ứng dụng báo lỗi rõ ràng, không tự tạo kết quả.
- Không có cơ sở dữ liệu thuốc đã xác minh tích hợp sẵn; không tự kê tên thuốc/liều lượng.

## Sơ đồ
- `index.html`, `manifest.webmanifest`, `sw.js`, `icon.svg`: giao diện PWA tĩnh.
- `worker.js`: máy chủ trung gian giữ bí mật khóa API.
- Khóa OpenAI chỉ được đặt trong Cloudflare Worker Secret, tuyệt đối không đưa vào `index.html` hoặc GitHub.

## Phần A — Đưa giao diện lên GitHub Pages bằng điện thoại Android
1. Mở Chrome, vào https://github.com/ và đăng ký/đăng nhập.
2. Bấm dấu `+` → `New repository`.
3. Đặt tên `long-ai-plant-doctor`, chọn `Public` (GitHub Pages miễn phí thường cần repo public ở tài khoản miễn phí), bấm `Create repository`.
4. Trong repo, bấm `Add file` → `Upload files`. Tải lên `index.html`, `manifest.webmanifest`, `sw.js`, `icon.svg`. Bấm `Commit changes`.
5. Vào `Settings` → `Pages`. Trong phần Build and deployment chọn `Deploy from a branch`, branch `main`, folder `/(root)`, bấm `Save`.
6. Chờ GitHub Pages công bố URL dạng `https://TEN-TAI-KHOAN.github.io/long-ai-plant-doctor/`.
7. Mở URL bằng Chrome Android → menu `⋮` → `Thêm vào màn hình chính` hoặc `Cài đặt ứng dụng` nếu tùy chọn hiện ra.

Lưu ý: đừng tải `worker.js` lên repo công khai nếu huynh muốn giữ cấu trúc máy chủ riêng; file này không chứa khóa bí mật nhưng nên triển khai riêng. Không bao giờ đưa khóa API thật vào GitHub.

## Phần B — Tạo API Worker để AI phân tích ảnh thật
1. Mở https://dash.cloudflare.com/ và đăng ký/đăng nhập.
2. Vào `Workers & Pages` → tạo Worker mới (tên ví dụ `long-plant-doctor-api`).
3. Mở phần chỉnh sửa mã nguồn Worker, thay mã mẫu bằng toàn bộ nội dung `worker.js` trong gói này, rồi Deploy.
4. Trong Worker → `Settings` → `Variables and Secrets`, thêm Secrets:
   - `OPENAI_API_KEY` = khóa API lấy từ https://platform.openai.com/api-keys
   - `APP_ACCESS_CODE` = một mã dài, khó đoán do huynh tự tạo
   - Có thể thêm biến thường `OPENAI_MODEL` = `gpt-4.1-mini` nếu tài khoản API hỗ trợ model này.
5. Lưu ý: tạo tài khoản ChatGPT không đồng nghĩa API miễn phí. OpenAI API có thể cần bật thanh toán và tính phí theo mức sử dụng. Kiểm tra giá và quyền truy cập model hiện tại trước khi dùng.
6. Sau khi Deploy, sao chép URL Worker, dạng `https://ten-worker.ten-tai-khoan.workers.dev`.
7. Mở PWA → dán URL Worker vào ô `Địa chỉ API Worker` → nhập đúng `APP_ACCESS_CODE` → chụp/tải ảnh → bấm `Phân tích ảnh bằng AI`.

## Phần C — Bảo vệ chi phí và dữ liệu
- `APP_ACCESS_CODE` hạn chế người không có mã gọi API, nhưng không phải hệ thống tài khoản hoàn chỉnh. Không chia sẻ mã công khai.
- Worker mẫu có CORS `*` để dễ khởi động. Khi đã chạy ổn định, nên giới hạn `Access-Control-Allow-Origin` về đúng URL GitHub Pages của huynh.
- Đặt giới hạn chi tiêu/usage alert trong tài khoản API nếu có; kiểm tra log và vô hiệu hóa khóa khi nghi bị lộ.
- Không gửi thông tin cá nhân, vị trí chính xác hoặc dữ liệu khách hàng không cần thiết.
- Ảnh được gửi đến nhà cung cấp AI để xử lý; chỉ sử dụng khi huynh chấp thuận chính sách dữ liệu của nhà cung cấp.
- PWA offline chỉ mở được vỏ giao diện đã cache; phân tích ảnh cần Internet và API hoạt động.

## Phần D — Cập nhật danh mục thuốc BVTV Việt Nam
Không dùng câu trả lời AI làm cơ sở dữ liệu đăng ký thuốc. Cần xây dựng quy trình kiểm tra riêng từ văn bản chính thức:
- Thông tư 75/2025/TT-BNNMT: https://vanban.chinhphu.vn/?classid=1&docid=216337&orggroupid=4&pageid=27160
- Thông tư 28/2026/TT-BNNMT sửa đổi, bổ sung: https://thuvienphapluat.vn/van-ban/Linh-vuc-khac/Thong-tu-28-2026-TT-BNNMT-sua-doi-Thong-tu-75-2025-TT-BNNMT-713084.aspx
Trước khi đề xuất sản phẩm, phải xác minh tên thương phẩm, hoạt chất, cây sầu riêng, đúng sinh vật gây hại, liều và thời gian cách ly theo nhãn. Nếu chưa xác minh được thì ghi “chưa xác minh — không khuyến nghị sản phẩm cụ thể”.

## Khung chẩn đoán đầu tiên — sầu riêng ra hoa/nuôi trái, đốm lá/vàng lá
Một ảnh lá không đủ để xác định chắc chắn nguyên nhân. Có thể cần phân biệt:
- bệnh đốm lá do nấm hoặc tác nhân khác;
- vấn đề vùng rễ/thoát nước, rễ tổn thương;
- mất cân đối dinh dưỡng hoặc pH/độ mặn;
- tổn thương do thuốc, nắng hoặc điều kiện thời tiết.
Cần ảnh mặt trên và mặt dưới lá, ảnh toàn cây, gốc/rễ nếu có, tỷ lệ cây bị, lịch mưa/tưới và lịch sử phun bón. Không phun hỗn hợp “phòng cho chắc”; đặc biệt chú ý ong thụ phấn, thiên địch và thời gian cách ly khi cây ra hoa/nuôi trái.

## Khắc phục lỗi thường gặp
- `401`: mã `APP_ACCESS_CODE` sai.
- `500`: chưa đặt Secrets hoặc tên biến sai.
- `502`: kiểm tra khóa API, số dư/hạn mức, quyền truy cập model và log Worker.
- Lỗi CORS: giới hạn/điều chỉnh CORS sau khi đã biết chính xác URL GitHub Pages.
- Không cài được PWA: phải mở bằng HTTPS; GitHub Pages cung cấp HTTPS.
