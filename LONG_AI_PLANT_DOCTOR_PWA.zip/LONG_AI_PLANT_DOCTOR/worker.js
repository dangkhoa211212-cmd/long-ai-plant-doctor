// Cloudflare Worker: keeps OPENAI_API_KEY on the server, never in the PWA.
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
    if (request.method !== "POST") return json({ error: "Chỉ hỗ trợ POST." }, 405);
    if (!env.OPENAI_API_KEY || !env.APP_ACCESS_CODE) {
      return json({ error: "Máy chủ chưa cấu hình OPENAI_API_KEY hoặc APP_ACCESS_CODE." }, 500);
    }
    let body;
    try { body = await request.json(); } catch { return json({ error: "JSON không hợp lệ." }, 400); }
    if (!body || body.accessCode !== env.APP_ACCESS_CODE) return json({ error: "Mã truy cập không đúng." }, 401);
    if (!Array.isArray(body.images) || body.images.length < 1 || body.images.length > 4) {
      return json({ error: "Cần gửi từ 1 đến 4 ảnh." }, 400);
    }
    const validImages = body.images.filter(x => typeof x === "string" && /^data:image\/(jpeg|png|webp);base64,/.test(x));
    if (!validImages.length) return json({ error: "Không tìm thấy ảnh hợp lệ." }, 400);

    const prompt = `Bạn là trợ lý hỗ trợ chẩn đoán cây trồng cho kỹ sư nông nghiệp tại Việt Nam. Hãy phân tích ảnh thật được gửi kèm cùng hồ sơ sau:
Cây trồng: ${safe(body.crop)}
Giai đoạn: ${safe(body.stage)}
Khu vực: ${safe(body.area)}
Tuổi cây/giống: ${safe(body.age)}
Triệu chứng người dùng quan sát: ${safe(body.symptoms)}
Điều kiện bổ sung: ${safe(body.conditions)}

YÊU CẦU AN TOÀN VÀ ĐỘ TIN CẬY:
- Chỉ mô tả những gì có thể quan sát trong ảnh; không khẳng định chắc chắn nếu ảnh không đủ bằng chứng.
- Đưa ra tối đa 3 khả năng chẩn đoán phân biệt, sắp xếp hợp lý, giải thích dấu hiệu ủng hộ và dấu hiệu còn thiếu.
- Phân biệt tác nhân sinh học với úng/rễ hư, dinh dưỡng, cháy nắng, tổn thương thuốc hoặc nguyên nhân phi sinh học nếu có thể.
- Nêu mức tin cậy bằng chữ (thấp/vừa/cao) và lý do; đây không phải xác suất đã được hiệu chuẩn.
- Đề nghị các câu hỏi/ảnh cần bổ sung và cách kiểm tra thực địa ít rủi ro.
- Không kê đơn thương mại cụ thể, không bịa tên thuốc, hoạt chất, liều pha, thời gian cách ly, hoặc tuyên bố thuốc được đăng ký. Không đề xuất phối trộn thuốc.
- Nếu cần thuốc BVTV, yêu cầu người dùng đối chiếu danh mục và nhãn hiện hành tại Việt Nam, đúng cây trồng + đối tượng gây hại; với sầu riêng đang ra hoa/nuôi trái nhắc bảo vệ ong, thiên địch, người phun và tuân thủ thời gian cách ly.
- Không tuyên bố ảnh đủ để xác nhận nấm/vi khuẩn/virus nếu cần xét nghiệm.
Trình bày tiếng Việt theo mục: (1) Quan sát ảnh, (2) Chẩn đoán phân biệt, (3) Mức tin cậy và giới hạn, (4) Kiểm tra tiếp theo, (5) Xử lý trước mắt, (6) Lưu ý thuốc BVTV và an toàn.`;

    try {
      const content = [{ type: "input_text", text: prompt }];
      for (const image_url of validImages) content.push({ type: "input_image", image_url, detail: "high" });
      const upstream = await fetch("https://api.openai.com/v1/responses", {
        method: "POST",
        headers: { "Authorization": `Bearer ${env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: env.OPENAI_MODEL || "gpt-4.1-mini",
          input: [{ role: "user", content }],
          max_output_tokens: 1400
        })
      });
      const result = await upstream.json();
      if (!upstream.ok) {
        return json({ error: `Dịch vụ AI trả lỗi HTTP ${upstream.status}: ${result.error?.message || "Không có chi tiết"}` }, 502);
      }
      const analysis = extractText(result);
      if (!analysis) return json({ error: "Phản hồi AI không có nội dung văn bản." }, 502);
      return json({ analysis, model: env.OPENAI_MODEL || "gpt-4.1-mini" }, 200);
    } catch (e) {
      return json({ error: `Không gọi được dịch vụ AI: ${String(e.message || e)}` }, 502);
    }
  }
};
function safe(v) { return String(v || "Chưa cung cấp").slice(0, 1800); }
function extractText(r) {
  if (typeof r.output_text === "string") return r.output_text;
  const out = [];
  for (const item of (r.output || [])) for (const c of (item.content || [])) if (c.type === "output_text" && c.text) out.push(c.text);
  return out.join("\n");
}
function json(data, status=200) {
  return new Response(JSON.stringify(data), { status, headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });
}